import { GoogleGenAI } from "@google/genai";
import { GeneratedCode } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

function toPascalCase(str: string): string {
    return str
        .replace(/[^a-zA-Z0-9\s]/g, '')
        .split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
        .join('');
}

export const generatePluginCode = async (pluginName: string, version: string, description: string): Promise<GeneratedCode> => {
    const className = toPascalCase(pluginName);
    const packageName = `com.example.${className.toLowerCase()}`;

    const prompt = `
You are an expert Minecraft Spigot plugin developer. Your task is to generate a complete and valid Spigot plugin from a user's description.

**User Request:**
- Plugin Name: "${pluginName}"
- Plugin Version: "${version}"
- Plugin Description: "${description}"

**Instructions:**
1.  Analyze the user's description to understand the core functionality.
2.  Generate the Java code for the main plugin class.
    - The class name **must** be \`${className}\`.
    - The package name **must** be \`${packageName}\`.
    - The code must extend \`JavaPlugin\`.
    - Implement any necessary listeners (\`Listener\`) and register them correctly in \`onEnable\`.
    - Implement any necessary commands (\`CommandExecutor\`) and register them correctly in \`onEnable\` and the plugin.yml.
    - Implement the logic described by the user.
    - Include all necessary Bukkit/Spigot API imports.
3.  Generate the \`plugin.yml\` configuration file.
    - The \`name\` must be "${pluginName}".
    - The \`version\` must be "${version}".
    - The \`main\` path must be \`${packageName}.${className}\`.
    - The \`api-version\` must be '1.20'.
    - Write a brief, one-sentence description for the YAML file based on the user's request.
    - Register any commands in the \`plugin.yml\` if the user's description implies them, including usage and description.

**Output Format:**
Respond with a single, raw JSON object. Do not include any other text, explanations, or markdown code fences. The JSON object must have the following structure:
{
  "javaCode": "...",
  "ymlCode": "..."
}
`;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-04-17",
        contents: prompt,
        config: {
            temperature: 0.2,
            responseMimeType: "application/json",
        }
    });
    
    let jsonStr = response.text.trim();
    
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
        jsonStr = match[2].trim();
    }
    
    try {
        const parsedData = JSON.parse(jsonStr);

        if (typeof parsedData.javaCode !== 'string' || typeof parsedData.ymlCode !== 'string') {
            throw new Error("AI response is missing required fields 'javaCode' or 'ymlCode'");
        }

        return {
            java: parsedData.javaCode,
            yml: parsedData.ymlCode,
            className,
            packageName,
        };
    } catch (e) {
        console.error("Failed to parse JSON response from AI:", jsonStr);
        throw new Error("The AI returned an invalid response format. Please try rephrasing your request.");
    }
};
