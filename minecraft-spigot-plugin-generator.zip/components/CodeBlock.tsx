
import React, { useState } from 'react';
import { ClipboardIcon } from './icons/ClipboardIcon';

interface CodeBlockProps {
    code: string;
    language: string;
}

export const CodeBlock: React.FC<CodeBlockProps> = ({ code, language }) => {
    const [isCopied, setIsCopied] = useState(false);

    const handleCopy = () => {
        navigator.clipboard.writeText(code).then(() => {
            setIsCopied(true);
            setTimeout(() => setIsCopied(false), 2000);
        });
    };

    return (
        <div className="relative bg-gray-900 rounded-b-lg group">
            <button
                onClick={handleCopy}
                className="absolute top-3 right-3 p-2 bg-gray-700 rounded-md text-gray-400 hover:bg-gray-600 hover:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-200 opacity-0 group-hover:opacity-100"
                aria-label="Copy code"
            >
                {isCopied ? (
                    <span className="text-xs font-semibold">Copied!</span>
                ) : (
                    <ClipboardIcon className="w-5 h-5" />
                )}
            </button>
            <pre className="p-4 overflow-x-auto text-sm leading-relaxed" style={{ fontFamily: '"Roboto Mono", monospace' }}>
                <code className={`language-${language}`}>
                    {code}
                </code>
            </pre>
        </div>
    );
};
